function getAns() {
var ans = document.getElementById('response').value
localStorage.setItem('answer', ans);
}

function onOrOff() {
var onOff = 'false'
localStorage.setItem('hasBeenOn1', onOff);
localStorage.setItem('hasBeenOn2', onOff);
localStorage.setItem('hasBeenOn3', onOff);
localStorage.setItem('hasBeenOn4', onOff);
localStorage.setItem('hasBeenOn5', onOff);
}