function getAns() {
var ans = document.getElementById('response').value
localStorage.setItem('answer', ans);
}
